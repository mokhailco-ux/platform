import { NextResponse } from "next/server";
import { requireAdminApi } from "@/lib/admin";
import { createAdminClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const admin = await requireAdminApi();
  if (!admin) return NextResponse.json({ error: "غير مصرّح" }, { status: 403 });

  const { grade, semester, title, description, youtubeId } = await request.json();
  if (!grade || !semester || !title || !youtubeId) return NextResponse.json({ error: "بيانات ناقصة" }, { status: 400 });
  if (!["ninth", "tenth"].includes(grade) || !["first", "second"].includes(semester)) {
    return NextResponse.json({ error: "صف أو فصل غير صالح" }, { status: 400 });
  }

  const supabase = createAdminClient();
  const { error } = await supabase.from("public_videos").insert({
    grade, semester, title, description: description || null, youtube_id: youtubeId,
  });

  if (error) return NextResponse.json({ error: "فشل الحفظ" }, { status: 500 });
  return NextResponse.json({ ok: true });
}
