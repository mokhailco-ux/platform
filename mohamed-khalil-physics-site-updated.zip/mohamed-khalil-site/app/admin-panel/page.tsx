import Link from "next/link";
import { FileUp, LogOut } from "lucide-react";
import { requireAdminPage } from "@/lib/admin";

export const dynamic = "force-dynamic";

export default async function AdminPanelHome() {
  const { profile } = await requireAdminPage();
  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <header className="flex items-center justify-between border-b border-navy-100 bg-white px-6 py-5 dark:border-navy-800 dark:bg-navy-900">
        <div>
          <h1 className="font-display text-lg font-bold text-navy-900 dark:text-white">لوحة إدارة المحتوى</h1>
          <p className="text-xs text-navy-400">مرحبًا {profile?.full_name ?? "أستاذ محمد"}</p>
        </div>
        <form action="/api/auth/logout" method="POST">
          <button className="flex items-center gap-2 text-sm font-bold text-navy-500 hover:text-red-500 dark:text-navy-300">
            <LogOut size={16} /> خروج
          </button>
        </form>
      </header>
      <div className="mx-auto max-w-4xl px-5 py-10">
        <Link href="/admin-panel/materials" className="card block p-7 transition-transform hover:-translate-y-1">
          <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-orange-500/10 text-orange-500">
            <FileUp size={22} />
          </span>
          <h2 className="mb-2 font-bold text-navy-900 dark:text-white">رفع فيديوهات وملفات PDF</h2>
          <p className="text-sm leading-6 text-navy-500 dark:text-navy-300">
            اختر الصف التاسع أو العاشر، ثم الفصل الأول أو الثاني، وارفع المحتوى ليظهر للزوار مجانًا.
          </p>
        </Link>
      </div>
    </div>
  );
}
