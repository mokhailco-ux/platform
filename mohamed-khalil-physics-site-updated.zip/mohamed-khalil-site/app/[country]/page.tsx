import type { Metadata } from "next";
import { notFound } from "next/navigation";
import HomePage from "@/components/HomePage";
import { countries, countryList, getCountry } from "@/lib/countries";

export function generateStaticParams() {
  return countryList.map((c) => ({ country: c.code }));
}

export function generateMetadata({ params }: { params: { country: string } }): Metadata {
  const country = getCountry(params.country);
  if (!country) return {};
  return {
    title: `محمد خليل | مدرس فيزياء ورياضيات أونلاين - ${country.name}`,
    description: `دروس أونلاين مجانية في الفيزياء والرياضيات لطلاب ${country.name} مع الأستاذ محمد خليل.`,
    alternates: { canonical: `/${country.code}` },
  };
}

export default function CountryPage({ params }: { params: { country: string } }) {
  const country = countries[params.country];
  if (!country) notFound();
  return <HomePage country={country} />;
}
