import HomePage from "@/components/HomePage";
import { countries } from "@/lib/countries";

export default function Home() {
  return <HomePage country={countries.jo} />;
}
