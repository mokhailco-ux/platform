-- قاعدة بيانات بسيطة للموقع: حسابات الإدارة + المحتوى المجاني فقط.
-- لا يوجد اشتراكات أو دفع أو منصة طلاب.

create table if not exists profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  full_name text,
  phone text,
  is_admin boolean default false,
  created_at timestamptz default now()
);

alter table profiles enable row level security;
drop policy if exists "المستخدم يشوف ملفه الشخصي فقط" on profiles;
create policy "المستخدم يشوف ملفه الشخصي فقط" on profiles for select using (auth.uid() = id);
drop policy if exists "المستخدم يعدّل ملفه الشخصي فقط" on profiles;
create policy "المستخدم يعدّل ملفه الشخصي فقط" on profiles for update using (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create table if not exists public_videos (
  id uuid default gen_random_uuid() primary key,
  grade text not null check (grade in ('ninth', 'tenth')),
  semester text not null check (semester in ('first', 'second')),
  title text not null,
  description text,
  youtube_id text not null,
  created_at timestamptz default now()
);

alter table public_videos enable row level security;
drop policy if exists "الجميع يقدر يشوف الفيديوهات المجانية" on public_videos;
create policy "الجميع يقدر يشوف الفيديوهات المجانية"
  on public_videos for select using (true);

create table if not exists public_materials (
  id uuid default gen_random_uuid() primary key,
  grade text not null check (grade in ('ninth', 'tenth')),
  semester text not null check (semester in ('first', 'second')),
  title text not null,
  file_path text not null,
  created_at timestamptz default now()
);

alter table public_materials enable row level security;
drop policy if exists "الجميع يقدر يشوف الملفات المجانية" on public_materials;
create policy "الجميع يقدر يشوف الملفات المجانية"
  on public_materials for select using (true);

insert into storage.buckets (id, name, public)
values ('public-materials', 'public-materials', true)
on conflict (id) do update set public = true;

-- بعد إنشاء حساب الإدارة، فعّل الحساب يدويًا:
-- update profiles set is_admin = true
-- where id = (select id from auth.users where email = 'ضع-بريدك-هنا@example.com');
