export type Semester = {
  id: "first" | "second";
  title: string;
  subjects: string[];
};

export type GradeSection = {
  id: "ninth" | "tenth";
  title: string;
  subtitle: string;
  semesters: Semester[];
};

export const gradeSections: GradeSection[] = [
  {
    id: "ninth",
    title: "الصف التاسع",
    subtitle: "المحتوى التعليمي للصف التاسع",
    semesters: [
      { id: "first", title: "الفصل الأول", subjects: ["فيزياء", "رياضيات"] },
      { id: "second", title: "الفصل الثاني", subjects: ["فيزياء", "رياضيات"] },
    ],
  },
  {
    id: "tenth",
    title: "الصف العاشر",
    subtitle: "المحتوى التعليمي للصف العاشر",
    semesters: [
      { id: "first", title: "الفصل الأول", subjects: ["فيزياء", "رياضيات"] },
      { id: "second", title: "الفصل الثاني", subjects: ["فيزياء", "رياضيات"] },
    ],
  },
];

export const gradeLabels: Record<string, string> = {
  ninth: "الصف التاسع",
  tenth: "الصف العاشر",
};

export const semesterLabels: Record<string, string> = {
  first: "الفصل الأول",
  second: "الفصل الثاني",
};
