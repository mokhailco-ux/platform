// ================================================================
// جميع بيانات الموقع القابلة للتعديل في مكان واحد.
// لإضافة دورة أو فيديو أو رأي طالب جديد، أضف عنصرًا جديدًا للمصفوفة
// المناسبة بنفس الشكل (نفس الحقول). لا حاجة لتعديل أي مكون آخر.
// ================================================================

export type Video = {
  id: string;
  youtubeId: string;
  title: string;
  description: string;
};

export const videos: Video[] = [
  {
    id: "v1",
    youtubeId: "dQw4w9WgXcQ",
    title: "مقدمة في قوانين نيوتن للحركة",
    description: "شرح مبسط لقوانين نيوتن الثلاثة مع أمثلة تطبيقية.",
  },
  {
    id: "v2",
    youtubeId: "dQw4w9WgXcQ",
    title: "كيف تحل مسائل الكهرباء الساكنة؟",
    description: "استراتيجية خطوة بخطوة لحل أصعب مسائل الكهرباء الساكنة.",
  },
  {
    id: "v3",
    youtubeId: "dQw4w9WgXcQ",
    title: "المعادلات التفاضلية ببساطة",
    description: "تبسيط فكرة المعادلات وربطها بتطبيقات الفيزياء.",
  },
];

export type Testimonial = {
  id: string;
  name: string;
  stage: string;
  rating: number; // من 5
  comment: string;
  avatar?: string;
};

export const testimonials: Testimonial[] = [
  {
    id: "t1",
    name: "عبدالله الشمري",
    stage: "ثالث ثانوي - مسار علمي",
    rating: 5,
    comment:
      "أسلوب الأستاذ محمد في تبسيط الفيزياء غيّر نظرتي للمادة بالكامل، من مادة صعبة لمادة ممتعة.",
  },
  {
    id: "t2",
    name: "سارة القحطاني",
    stage: "ثاني ثانوي",
    rating: 5,
    comment:
      "المتابعة المستمرة وحل الواجبات أول بأول ساعدني أرفع درجاتي بشكل ملحوظ خلال فصل واحد.",
  },
  {
    id: "t3",
    name: "فيصل العتيبي",
    stage: "أول ثانوي",
    rating: 4,
    comment: "شرح منظم وهادئ، والأمثلة قريبة من نمط أسئلة الاختبارات فعليًا.",
  },
];

export type FaqItem = {
  id: string;
  question: string;
  answer: string;
};

export const faqs: FaqItem[] = [
  {
    id: "f1",
    question: "كيف تتم الدراسة؟ هل هي مباشرة أم مسجلة؟",
    answer:
      "تجمع الدورات بين حصص مباشرة أسبوعية عبر Zoom وفيديوهات مسجلة يمكن مشاهدتها في أي وقت لمراجعة الدروس.",
  },
  {
    id: "f2",
    question: "هل يوجد اختبارات ومتابعة لمستوى الطالب؟",
    answer:
      "نعم، تتضمن كل دورة اختبارات دورية وتقارير أداء دورية تُرسل لولي الأمر لمتابعة تطور الطالب أولًا بأول.",
  },
  {
    id: "f4",
    question: "هل يمكن الانضمام في أي وقت خلال الفصل الدراسي؟",
    answer:
      "بالتأكيد، يمكنك الانضمام في أي وقت وسيتم تزويدك بجميع التسجيلات السابقة للحاق بالمجموعة.",
  },
  {
    id: "f5",
    question: "هل تتوفر حصص فردية (خصوصي)؟",
    answer:
      "نعم، تتوفر حصص فردية بجدول مرن حسب توفر المواعيد، تواصل عبر واتساب لتحديد التفاصيل والسعر.",
  },
];

export const stats = {
  students: 1280,
  courses: 24,
  hours: 950,
};

export const social = {
  whatsapp: "https://wa.me/962700000000",
  telegram: "https://t.me/mohamedkhalil",
  facebook: "https://facebook.com/mohamedkhalil",
  instagram: "https://instagram.com/mohamedkhalil",
};
