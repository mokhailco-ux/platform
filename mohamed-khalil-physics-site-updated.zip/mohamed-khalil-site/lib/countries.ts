// بيانات الموقع الخاصة بالأردن فقط. تم إلغاء اختلاف الدول والأسعار والعملات.

export type CountryCourse = {
  id: string;
  title: string;
  stage: string;
  subject: "فيزياء" | "رياضيات";
  price: number;
  oldPrice?: number;
  description: string;
  features: string[];
  badge?: string;
};

export type CountryFaq = {
  id: string;
  question: string;
  answer: string;
};

export type Country = {
  code: string;
  name: string;
  flag: string;
  currency: string;
  whatsapp: string;
  heroLine: string;
  aboutText: string[];
  courses: CountryCourse[];
  faqs: CountryFaq[];
};

export const countries: Record<string, Country> = {
  jo: {
    code: "jo",
    name: "الأردن",
    flag: "🇯🇴",
    currency: "د.أ",
    whatsapp: "https://wa.me/962700000000",
    heroLine: "فيزياء • رياضيات — التوجيهي الأردني",
    aboutText: [
      "أنا الأستاذ محمد خليل، مدرس فيزياء ورياضيات أونلاين متخصص في تدريس طلاب التوجيهي بالأردن. أؤمن أن أي طالب يستطيع التفوق إذا فهم الفكرة قبل الحفظ، لذلك أبني كل درس على أساس منطقي متسلسل يربط القانون بمعناه الفعلي قبل تطبيقه في المسائل.",
      "أسلوبي بالتدريس يعتمد على التفاعل المباشر، حل أسئلة وزارية سابقة، ومتابعة دقيقة لتقدم كل طالب حتى يوصل لأعلى علامة بالتوجيهي.",
    ],
    courses: [
      {
        id: "jo-physics-10",
        title: "فيزياء الصف العاشر - شامل",
        stage: "الصف العاشر",
        subject: "فيزياء",
        price: 15,
        description: "شرح منهج الصف العاشر كامل مع حل أوراق عمل وامتحانات دورية.",
        features: ["+35 ساعة شرح", "أوراق عمل", "متابعة أسبوعية"],
      },
      {
        id: "jo-physics-11",
        title: "فيزياء أول ثانوي (علمي)",
        stage: "أول ثانوي علمي",
        subject: "فيزياء",
        price: 18,
        description: "تأسيس المسار العلمي في الميكانيكا والكهرباء.",
        features: ["+40 ساعة شرح", "حصص حل مسائل", "جروب دعم"],
      },
      {
        id: "jo-physics-tawjihi",
        title: "فيزياء التوجيهي - مراجعة شاملة",
        stage: "التوجيهي (الثاني ثانوي)",
        subject: "فيزياء",
        price: 25,
        oldPrice: 30,
        description: "مراجعة مكثفة تناسب امتحان التوجيهي مع نماذج أسئلة وزارية سابقة.",
        features: ["+55 ساعة شرح", "أسئلة وزارية سابقة", "استشارة فردية"],
        badge: "الأكثر طلبًا",
      },
      {
        id: "jo-math-all",
        title: "رياضيات جميع المراحل - باقة شاملة",
        stage: "جميع المراحل",
        subject: "رياضيات",
        price: 20,
        description: "تغطية كاملة لمنهج الرياضيات بالمنهاج الأردني.",
        features: ["تحديث مستمر للمحتوى", "حل واجبات دورية", "دعم فني مباشر"],
      },
    ],
    faqs: [
      { id: "jo-f1", question: "كيف تتم الدراسة؟ هل هي مباشرة أم مسجلة؟", answer: "تجمع الدورات بين حصص مباشرة أسبوعية عبر Zoom وفيديوهات مسجلة يمكن مشاهدتها بأي وقت لمراجعة الدروس." },
      { id: "jo-f2", question: "هل يوجد اختبارات ومتابعة لمستوى الطالب؟", answer: "نعم، كل دورة فيها اختبارات دورية وتقارير أداء تُرسل لولي الأمر لمتابعة تطور الطالب أولًا بأول." },
      { id: "jo-f3", question: "هل المحتوى مجاني؟", answer: "نعم، كل المحتوى التعليمي من فيديوهات وملفات PDF مجاني للجميع، أما الحصص الخاصة فيتم حجزها والتنسيق عليها مباشرة عبر واتساب." },
      { id: "jo-f4", question: "هل تتوفر حصص فردية (خصوصي)؟", answer: "نعم، تتوفر حصص فردية بجدول مرن حسب توفر المواعيد، تواصل عبر واتساب لتحديد التفاصيل والسعر." },
    ],
  },
};

export const countryList = Object.values(countries);

export function getCountry(code: string): Country | undefined {
  return countries[code];
}
