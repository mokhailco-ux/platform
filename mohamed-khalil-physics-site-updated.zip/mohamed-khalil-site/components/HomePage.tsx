import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Stats from "@/components/Stats";
import About from "@/components/About";
import Courses from "@/components/Courses";
import Videos from "@/components/Videos";
import Testimonials from "@/components/Testimonials";
import FAQ from "@/components/FAQ";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import ScrollToTop from "@/components/ScrollToTop";
import WhatsAppButton from "@/components/WhatsAppButton";
import type { Country } from "@/lib/countries";
import AdSlot from "@/components/AdSlot";
import PublicMaterials from "@/components/PublicMaterials";

export default function HomePage({ country }: { country: Country }) {
  return (
    <>
      <Header country={country} />
      <main>
        <Hero country={country} />
        <Stats />
        <About country={country} />
        <AdSlot />
        <Courses country={country} />
        <Videos />
        <PublicMaterials />
        <Testimonials />
        <AdSlot />
        <FAQ country={country} />
        <Contact country={country} />
      </main>
      <Footer country={country} />
      <ScrollToTop />
      <WhatsAppButton country={country} />
    </>
  );
}
