import { FileText, Download } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { gradeLabels, semesterLabels } from "@/lib/education";

export default async function PublicMaterials() {
  const supabase = createClient();
  const { data: materials } = await supabase
    .from("public_materials")
    .select("id, title, file_path, grade, semester")
    .order("created_at", { ascending: false });

  if (!materials?.length) return null;

  return (
    <section id="materials" className="section-padding mx-auto max-w-6xl">
      <div className="mx-auto max-w-2xl text-center">
        <span className="eyebrow">ملفات PDF</span>
        <h2 className="font-display text-3xl font-extrabold text-navy-900 dark:text-white sm:text-4xl">
          ملفات مجانية للتحميل
        </h2>
        <p className="mt-4 text-navy-500 dark:text-navy-300">
          ملازم، أوراق عمل وحلول متاحة للجميع بدون تسجيل أو اشتراك.
        </p>
      </div>
      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {materials.map((material) => {
          const { data } = supabase.storage.from("public-materials").getPublicUrl(material.file_path);
          return (
            <a key={material.id} href={data.publicUrl} target="_blank" rel="noopener noreferrer" className="card flex items-start gap-4 p-5 hover:-translate-y-0.5">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-orange-500/10 text-orange-500">
                <FileText size={20} />
              </span>
              <span className="min-w-0">
                <span className="block font-bold text-navy-900 dark:text-white">{material.title}</span>
                <span className="mt-1 block text-xs text-navy-400">{gradeLabels[material.grade]} • {semesterLabels[material.semester]}</span>
                <span className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-orange-500"><Download size={13} /> فتح الملف</span>
              </span>
            </a>
          );
        })}
      </div>
    </section>
  );
}
