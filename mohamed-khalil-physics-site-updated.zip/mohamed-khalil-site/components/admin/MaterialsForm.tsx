"use client";

import { useState, type FormEvent } from "react";
import { FileUp, Video, Loader2, CheckCircle2 } from "lucide-react";
import { gradeLabels, semesterLabels } from "@/lib/education";

const grades = ["ninth", "tenth"] as const;
const semesters = ["first", "second"] as const;

export default function MaterialsForm() {
  const [pdfStatus, setPdfStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [videoStatus, setVideoStatus] = useState<"idle" | "loading" | "done" | "error">("idle");

  async function handlePdfSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPdfStatus("loading");
    const res = await fetch("/api/admin/materials/upload", { method: "POST", body: new FormData(e.currentTarget) });
    setPdfStatus(res.ok ? "done" : "error");
    if (res.ok) e.currentTarget.reset();
  }

  async function handleVideoSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setVideoStatus("loading");
    const fd = new FormData(e.currentTarget);
    const res = await fetch("/api/admin/videos/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        grade: fd.get("grade"),
        semester: fd.get("semester"),
        title: fd.get("title"),
        description: fd.get("description"),
        youtubeId: fd.get("youtubeId"),
      }),
    });
    setVideoStatus(res.ok ? "done" : "error");
    if (res.ok) e.currentTarget.reset();
  }

  return (
    <div className="space-y-8">
      <div className="rounded-2xl border border-orange-500/20 bg-orange-500/5 p-5 text-sm leading-7 text-navy-600 dark:text-navy-200">
        كل المحتوى المنشور هنا مجاني ويظهر للزوار مباشرة، بدون حساب أو اشتراك.
      </div>

      <form onSubmit={handlePdfSubmit} className="card space-y-4 p-6">
        <h2 className="flex items-center gap-2 font-bold text-navy-900 dark:text-white">
          <FileUp size={18} className="text-orange-500" /> رفع ملف PDF
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <select name="grade" required className="input-field">
            <option value="">اختر الصف</option>
            {grades.map((grade) => <option key={grade} value={grade}>{gradeLabels[grade]}</option>)}
          </select>
          <select name="semester" required className="input-field">
            <option value="">اختر الفصل</option>
            {semesters.map((semester) => <option key={semester} value={semester}>{semesterLabels[semester]}</option>)}
          </select>
        </div>
        <input name="title" required placeholder="عنوان الملف (مثال: حل اختبار الفصل الأول)" className="input-field" />
        <input name="file" type="file" accept="application/pdf" required className="input-field" />
        <button type="submit" disabled={pdfStatus === "loading"} className="btn-primary w-full justify-center disabled:opacity-60">
          {pdfStatus === "loading" ? <Loader2 size={18} className="animate-spin" /> : pdfStatus === "done" ? <CheckCircle2 size={18} /> : <FileUp size={18} />}
          {pdfStatus === "done" ? "تم الرفع بنجاح" : "رفع الملف"}
        </button>
        {pdfStatus === "error" && <p className="text-sm text-red-500">فشل الرفع - تأكد أن الملف PDF وحاول مجددًا.</p>}
      </form>

      <form onSubmit={handleVideoSubmit} className="card space-y-4 p-6">
        <h2 className="flex items-center gap-2 font-bold text-navy-900 dark:text-white">
          <Video size={18} className="text-electric-500" /> إضافة فيديو شرح
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <select name="grade" required className="input-field">
            <option value="">اختر الصف</option>
            {grades.map((grade) => <option key={grade} value={grade}>{gradeLabels[grade]}</option>)}
          </select>
          <select name="semester" required className="input-field">
            <option value="">اختر الفصل</option>
            {semesters.map((semester) => <option key={semester} value={semester}>{semesterLabels[semester]}</option>)}
          </select>
        </div>
        <input name="title" required placeholder="عنوان الفيديو" className="input-field" />
        <input name="description" placeholder="وصف مختصر (اختياري)" className="input-field" />
        <input name="youtubeId" required placeholder="معرّف فيديو يوتيوب (بعد v=)" className="input-field" />
        <button type="submit" disabled={videoStatus === "loading"} className="btn-secondary w-full justify-center disabled:opacity-60">
          {videoStatus === "loading" ? <Loader2 size={18} className="animate-spin" /> : videoStatus === "done" ? <CheckCircle2 size={18} /> : <Video size={18} />}
          {videoStatus === "done" ? "تمت الإضافة" : "إضافة الفيديو"}
        </button>
        {videoStatus === "error" && <p className="text-sm text-red-500">فشلت الإضافة، حاول مجددًا.</p>}
      </form>
    </div>
  );
}
