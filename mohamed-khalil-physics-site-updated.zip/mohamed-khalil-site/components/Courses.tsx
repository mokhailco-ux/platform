"use client";

import { motion } from "framer-motion";
import { Check, MessageCircle, Sparkles } from "lucide-react";
import type { Country } from "@/lib/countries";
import { gradeSections } from "@/lib/education";

export default function Courses({ country }: { country: Country }) {
  const whatsapp = country.whatsapp;
  const physics10 = country.courses.find((c) => c.id === "jo-physics-10");

  function bookingUrl(label: string) {
    return `${whatsapp}?text=${encodeURIComponent(`مرحبًا، أرغب بحجز حصة في ${label}`)}`;
  }

  return (
    <section id="courses" className="section-padding bg-navy-50/60 dark:bg-navy-900/20">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">المحتوى التعليمي</span>
          <h2 className="font-display text-3xl font-extrabold text-navy-900 dark:text-white sm:text-4xl">
            كل المحتوى مجاني
          </h2>
          <p className="mt-4 leading-7 text-navy-500 dark:text-navy-300">
            اختر صفك، ثم الفصل الدراسي، واستعرض الدروس والملفات والفيديوهات المتاحة مجانًا.
            ولحجز حصة خاصة، يمكنك التواصل معي مباشرة عبر واتساب.
          </p>
        </div>

        <div className="mt-14 space-y-10">
          {gradeSections.map((grade, gradeIndex) => (
            <motion.div
              key={grade.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: gradeIndex * 0.08 }}
              className="card overflow-hidden p-6 sm:p-8"
            >
              <div className="flex flex-col gap-2 border-b border-navy-100 pb-6 dark:border-navy-700 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <span className="eyebrow mb-1">المستوى الدراسي</span>
                  <h3 className="font-display text-2xl font-extrabold text-navy-900 dark:text-white">
                    {grade.title}
                  </h3>
                </div>
                <p className="text-sm text-navy-500 dark:text-navy-300">{grade.subtitle}</p>
              </div>

              <div className="mt-7 grid gap-6 lg:grid-cols-2">
                {grade.semesters.map((semester) => (
                  <div
                    key={semester.id}
                    className="rounded-2xl border border-navy-100 bg-white/70 p-5 dark:border-navy-700 dark:bg-navy-900/40"
                  >
                    <h4 className="font-display text-lg font-extrabold text-navy-900 dark:text-white">
                      {semester.title}
                    </h4>
                    <div className="mt-4 grid gap-3 sm:grid-cols-2">
                      {semester.subjects.map((subject) => (
                        <a
                          key={subject}
                          href={bookingUrl(`${grade.title} - ${semester.title} - ${subject}`)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="group rounded-xl border border-navy-100 bg-white p-4 transition-all hover:-translate-y-0.5 hover:border-orange-500/40 dark:border-navy-700 dark:bg-navy-800"
                        >
                          <span className="text-xs font-bold text-orange-500">{subject}</span>
                          <h5 className="mt-1 font-bold text-navy-900 dark:text-white">
                            {subject} {grade.title}
                          </h5>
                          <p className="mt-1 text-xs leading-5 text-navy-500 dark:text-navy-300">
                            دروس وشرح وملفات مجانية
                          </p>
                          <span className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-navy-500 group-hover:text-orange-500 dark:text-navy-300">
                            <MessageCircle size={14} /> احجز حصتك عبر واتساب
                          </span>
                        </a>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {physics10 && (
          <div className="mt-10 rounded-2xl border border-orange-500/20 bg-orange-500/5 p-6 text-center">
            <p className="font-bold text-navy-900 dark:text-white">{physics10.title}</p>
            <p className="mt-2 text-sm text-navy-500 dark:text-navy-300">{physics10.description}</p>
            <ul className="mt-4 flex flex-wrap justify-center gap-3">
              {physics10.features.map((feature) => (
                <li key={feature} className="inline-flex items-center gap-1 text-sm text-navy-600 dark:text-navy-200">
                  <Check size={15} className="text-orange-500" /> {feature}
                </li>
              ))}
            </ul>
            {physics10.badge && (
              <span className="mt-4 inline-flex items-center gap-1 rounded-full bg-orange-500/10 px-3 py-1 text-xs font-bold text-orange-600">
                <Sparkles size={12} /> {physics10.badge}
              </span>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
