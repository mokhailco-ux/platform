"use client";

import { useEffect } from "react";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

export default function AdSlot() {
  const client = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  const slot = process.env.NEXT_PUBLIC_ADSENSE_SLOT;

  useEffect(() => {
    if (!client || !slot) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      // AdSense may be blocked by an extension or not ready yet.
    }
  }, [client, slot]);

  return (
    <section aria-label="إعلان" className="mx-auto max-w-6xl px-5 py-8 sm:px-8 lg:px-16">
      <div className="flex min-h-28 items-center justify-center overflow-hidden rounded-2xl border border-dashed border-navy-200 bg-navy-50/50 dark:border-navy-700 dark:bg-navy-900/30">
        {client && slot ? (
          <ins
            className="adsbygoogle block min-h-24 w-full"
            style={{ display: "block" }}
            data-ad-client={client}
            data-ad-slot={slot}
            data-ad-format="auto"
            data-full-width-responsive="true"
          />
        ) : (
          <div className="text-center">
            <span className="text-[11px] font-bold tracking-widest text-navy-400">إعلان</span>
            <p className="mt-1 text-xs text-navy-400">مكان جاهز لإعلانات Google AdSense</p>
          </div>
        )}
      </div>
    </section>
  );
}
