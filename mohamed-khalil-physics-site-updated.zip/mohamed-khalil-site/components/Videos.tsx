import { PlayCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { videos as fallbackVideos } from "@/lib/data";
import { gradeLabels, semesterLabels } from "@/lib/education";

export default async function Videos() {
  const supabase = createClient();
  const { data: publicVideos } = await supabase
    .from("public_videos")
    .select("id, title, description, youtube_id, grade, semester")
    .order("created_at", { ascending: false });

  const videos = [
    ...((publicVideos ?? []).map((video) => ({
      id: video.id,
      youtubeId: video.youtube_id,
      title: video.title,
      description: `${gradeLabels[video.grade] ?? video.grade} • ${semesterLabels[video.semester] ?? video.semester}${video.description ? ` — ${video.description}` : ""}`,
    }))),
    ...fallbackVideos,
  ];

  return (
    <section id="videos" className="section-padding mx-auto max-w-6xl">
      <div className="mx-auto max-w-xl text-center">
        <span className="eyebrow">مكتبة الفيديوهات</span>
        <h2 className="font-display text-3xl font-extrabold text-navy-900 dark:text-white sm:text-4xl">
          شاهد نماذج من الشرح
        </h2>
        <p className="mt-4 text-navy-500 dark:text-navy-300">
          مجموعة من الفيديوهات التعليمية المجانية لتتعرف على أسلوب الشرح وتستفيد من المحتوى مجانًا.
        </p>
      </div>

      <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((video) => (
          <div key={video.id} className="card overflow-hidden">
            <div className="relative aspect-video w-full overflow-hidden bg-navy-800">
              <iframe
                className="h-full w-full"
                src={`https://www.youtube.com/embed/${video.youtubeId}`}
                title={video.title}
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="p-5">
              <h3 className="flex items-start gap-2 font-bold text-navy-900 dark:text-white">
                <PlayCircle size={18} className="mt-0.5 shrink-0 text-orange-500" />
                {video.title}
              </h3>
              <p className="mt-2 text-sm leading-6 text-navy-500 dark:text-navy-300">{video.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
