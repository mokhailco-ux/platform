"use client";

import { useEffect, useState } from "react";
import { Menu, X, Atom } from "lucide-react";
import ThemeToggle from "./ThemeToggle";
import type { Country } from "@/lib/countries";

const links = [
  { href: "#about", label: "نبذة عني" },
  { href: "#courses", label: "الدورات" },
  { href: "#videos", label: "الفيديوهات" },
  { href: "#testimonials", label: "آراء الطلاب" },
  { href: "#faq", label: "الأسئلة الشائعة" },
  { href: "#contact", label: "تواصل معي" },
];

export default function Header({ country }: { country: Country }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/80 dark:bg-navy-950/80 backdrop-blur-md shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8 lg:px-16">
        <a href="#" className="flex items-center gap-2 font-display font-extrabold text-navy-900 dark:text-white">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-full text-white shadow-md shadow-orange-500/30"
            style={{ background: "linear-gradient(135deg, #ff9a5a, #e8600f)" }}
          >
            <Atom size={18} />
          </span>
          <span className="text-lg">أ. محمد خليل</span>
        </a>

        <nav className="hidden items-center gap-8 lg:flex">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-navy-600 transition-colors hover:text-orange-500 dark:text-navy-200 dark:hover:text-orange-400"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <a href={country.whatsapp} target="_blank" rel="noopener noreferrer" className="btn-primary hidden !px-5 !py-2.5 text-sm sm:inline-flex">
            احجز الآن
          </a>
          <button
            onClick={() => setOpen(!open)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-navy-200 dark:border-navy-600 lg:hidden"
            aria-label="فتح القائمة"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* قائمة الجوال */}
      {open && (
        <nav className="flex flex-col gap-1 border-t border-navy-100 bg-white px-5 py-4 dark:border-navy-800 dark:bg-navy-950 lg:hidden">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-3 text-sm font-medium text-navy-700 hover:bg-navy-50 dark:text-navy-200 dark:hover:bg-navy-800"
            >
              {link.label}
            </a>
          ))}
          <a href={country.whatsapp} target="_blank" rel="noopener noreferrer" onClick={() => setOpen(false)} className="btn-primary mt-2 justify-center">
            احجز الآن
          </a>
        </nav>
      )}
    </header>
  );
}
